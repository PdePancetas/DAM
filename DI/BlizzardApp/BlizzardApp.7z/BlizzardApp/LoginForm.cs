﻿using System;
using System.Windows.Forms;

namespace BlizzardApp
{
    public partial class LoginForm : Form
    {
        public static string usuarioLog;
        


        public LoginForm()
        {
            if(usuarios.Count == 0 && passwords.Count == 0)
                rellenarDatos();

            InitializeComponent();
        }

        private void rellenarDatos()
        {
            for (int i = 1; i <= 10; i++)
            {
                usuarios.Add("user" + i);
            }
            for (int i = 1; i <= 10; i++)
            {
                passwords.Add("pw" + i);
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text;
            string contrasena = txtContrasena.Text;
            int pos = 0;
            Boolean encontrado = false;
            Boolean coincide = false;
            for (int i = 0; i < usuarios.Count; i++)
            {
                if (usuarios[i] == usuario)
                {
                    pos = i;
                    encontrado = true;
                    break;
                }
            }

            if (encontrado && passwords[pos] == contrasena) 
            { 
                coincide = true;
            }
            if ((usuario == "" && contrasena == "") || (usuario == "")) 
            {
                MessageBox.Show("No se han introducido los datos correctamente!!","Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (encontrado && coincide)
            {
                MessageBox.Show("Inicio de sesión exitoso", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                usuarioLog = usuario;
                this.Hide();  
                Home home = new Home();
                home.Show();
            }
            else if(encontrado && !coincide)
            {
                MessageBox.Show("Contraseña incorrecta", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //Control de bloqueo de usuario si se introduce 3 veces mal la contraseña
                txtContrasena.Text = "";
            }
            else
            {
                DialogResult dr = MessageBox.Show("Usuario no encontrado, quiere registrarlo?", "Error", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
                if(dr == DialogResult.Yes && txtContrasena.Text == "")
                {
                    MessageBox.Show("Rellena la contraseña y luego pulsa en registrarse", "Login", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtContrasena.Text = "";
                } else if (dr == DialogResult.Yes)
                {
                    usuarios.Add(txtUsuario.Text);
                    passwords.Add(txtContrasena.Text);
                    MessageBox.Show("Te has registrado correctamente!", "Registro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtUsuario.Text = "";
                    txtContrasena.Text = "";
                }
                
            }
        }

        private void LoginForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit(); 
        }

        private void Salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (txtUsuario.Text == "" && txtContrasena.Text == "")
            {
                MessageBox.Show("Rellena el usuario y contraseña y pulsa en registrar!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                usuarios.Add(txtUsuario.Text);
                passwords.Add(txtContrasena.Text);
                MessageBox.Show("Te has registrado correctamente!", "Registro", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            }
        }
}

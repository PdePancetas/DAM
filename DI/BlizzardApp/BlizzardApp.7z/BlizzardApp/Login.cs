﻿using System;
using System.Windows.Forms;

namespace BlizzardApp
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        // Método para validar el inicio de sesión
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text;
            string contrasena = txtContrasena.Text;

            // Validación simple (puedes usar un sistema de autenticación más complejo)
            if (usuario == "admin" && contrasena == "1234")
            {
                MessageBox.Show("Inicio de sesión exitoso", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Cerrar el formulario de login y abrir la siguiente ventana
                this.Hide();  // Oculta la ventana de login
                MainForm mainForm = new MainForm();  // Crea la instancia del formulario principal
                mainForm.Show();  // Muestra la ventana principal
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Método de cierre (en caso de querer cerrarlo de forma más controlada)
        private void LoginForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();  // Cierra la aplicación completamente si se cierra el formulario
        }
    }
}

